<?php
    $name = "홍길동";
    $age = 2200;
    $height = 177.32;
    $blood_type = 'O';

    printf("제이름은 %s입니다. 나이는 %d세이고, 키는 %fcm입니다. 혈액형은 %s입니다.<br>"
            , $name, $age, $height, $blood_type );

            // %자리가 변수나 값이 들어가는 자리.
            // %string을 줄임말 = %s
    
    print "<br>";
            
    // 키부분 소숫점 어디까지 나타낼껀지.
    printf("제이름은 %s입니다. 나이는 %4d세이고, 키는 %.2fcm입니다. 혈액형은 %s입니다.<br>"
    , $name, $age, $height, $blood_type );

    // 천단위 콤마, 쓸때, number_format() 사용
    printf("제이름은 %s입니다. 나이는 %d세이고, 키는 %.2fcm입니다. 혈액형은 %s입니다.<br>"
    , $name, $age, $height, $blood_type );

    print "<br>";
    
    sprintf("제이름은 %s입니다. 나이는 %d세이고, 키는 %.2fcm입니다. 혈액형은 %s입니다.<br>"
    , $name, $age, $height, $blood_type );
    // sprintf는 이 결과물을 리턴해주는 것이 목적.
    $str = sprintf("제이름은 %s입니다. 나이는 %d세이고, 키는 %.2fcm입니다. 혈액형은 %s입니다.<br>"
    , $name, $age, $height, $blood_type );
    //함수가 리턴해주는 것을 가지고 싶을때, 변수에 넣어주면 됨.
    print $str; //리턴한 값을 출력하고 싶을때! 

