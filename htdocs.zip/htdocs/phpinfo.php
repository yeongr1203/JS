<?php
    echo phpinfo();