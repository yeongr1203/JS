<?php

    $seoul = getdate();     // getdate함수 호출.        // new Date();  와 같음.
    // 배열을 리턴.

    print " 현재시간 : ".
            $seoul["year"] . "년" . 
            $seoul["mon"] . "월" .
            $seoul["mday"] . "일" .
            $seoul["hours"] . "시" .
            $seoul["minutes"] . "분" .
            $seoul["seconds"] ."초";

    // 이건 내가 설정된 php시간이 나타남.
    print "<br>-----------<br>";

    $year = gmdate("Y");
    $mon = gmdate("m");
    $day = gmdate("d");
    $hour = gmdate("H");
    $min = gmdate("i");
    $sec = gmdate("s");

    print "현재시간 ${year}년 ${mon}월 ${$day}일 ${hour}:${min}:${sec} <br>";
    // 세계표준시간이 나타남. = 그리니치 표준시

    print mt_rand(1,20); // 0.000



?>
<!-- 

자주 쓰이진 않겠지만, 날짜 찍을 때 사용하면 됨.

글로벌 서비스를 하면 gmdate 함.

우리 프로젝트일땐, 아마  getdate() 를 사용함.
함수호출하면 리턴하여 값을 주기때문에, 그 값이 배열일 경우, 배열을 줌.
아래 배열에는 [] 대괄호를 같이 사용함. 배열이기때문에.
외울 필요는 없다.



 -->