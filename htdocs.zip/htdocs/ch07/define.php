<?php

    // 상수면 다 대문자 사용.
    // 상수에 쓸때 _언더바를 앞에 써던지 나만의 약속을 정하기. 
    define("NAME", "홍길동");
    define("NAME2", "장보고");
    define("STAND_AGE", 20);        // STAND_AGE = 상수, 20은 리터럴.
    
    // 상수 const vs 리터럴 literal

    print NAME;
    print NAME2;
    print STAND_AGE;
    print "-----------------<br>";
    
    function fn1() {
        print " fn : ". NAME . "<br>";
    }

    // 함수안에서 상수 선언되는지 확인... 되지만 위에서 선언하고 사용하기!!
    function fn2() {
        define( "TEST", "테스트");
    }

    fn1();
    fn2();
    print TEST."<br>";
?>
<!-- 
define은 호출만 되면 사용되는 범위는 전역이다.
밖에 있어도 함수안에 작성하지 않아도 호출해서 사용이 가능.
dfine은 작성은 함수설정 위에 하는 걸로!


상수만 쓸때 사용.



 -->