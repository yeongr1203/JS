<?php

    // 이미지 업로드 할 때, 보통 사용함.
    print  __FILE__ ."<br>";
    print  __LINE__ ."<br>";
    print  __LINE__ ."<br>";
    print "PHP VERSION : ". PHP_VERSION . "<br>";       //php 버전 알고싶을때,
    print "OS : " .PHP_OS. "<br>";                      // 실행된 PC의 OS 확인 가능.
    
    $GLOBALS["foo"] = 10;                               // $GLOBALS는 
    $GLOBALS["foo"] = 11;

    print "-- 글로벌상수 -- <br>";
    foreach($GLOBALS as $key => $var)
    {
        print $key . " : ";
        print_r ($var);
        print "<br>";
    }

    $arr = array (
        "name" => "홍길동",
        "age" => 20,
        ""

    );

    // while(list($key, $var) = each ($GLOBALS))
    // {
    //     print $key. " : ";
    //     print_r($var);
    //     print "<br>";
    // } == 이건 8버전 부터 사라짐.

    // $GLOBALS = 슈퍼글로벌 중 하나.
    // $GLOBALS  = 글로벌 상수. 

?>
<!-- 

__FINE__  한다면, 지금 실행되고 있는것이 나옴.
__LINE__ 이것은 라인에 있는 것을 알려줌.


 $GLOBALS[값] 은 




 -->