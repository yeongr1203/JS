CREATE DATABASE Project;

CREATE TABLE t_user(
	i_user INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	uid VARCHAR(20) unique NOT NULL,
	upw VARCHAR(20) NOT NULL,
	nm VARCHAR(5) NOT NULL,
	gender INT unsigned not null CHECK(gender IN (0,1)),
	created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
SELECT * FROM t_user;

CREATE TABLE t_board(
	i_board INT UNSIGNED AUTO_INCREMENT,
	PRIMARY KEY(i_board),
	title VARCHAR(100) NOT NULL,
	ctnt VARCHAR(2000) NOT NULL,
	i_user INT UNSIGNED NOT NULL,
	created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY(i_user) REFERENCES t_user(i_user)
);

SELECT * FROM t_board;

/* 공구 페이지  */
CREATE TABLE t_gg_sel(
  i_gonggu int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  title varchar(100) NOT NULL,
  ctnt varchar(2000) NOT NULL,
  plant_nm varchar(100) NOT NULL,
  num int(10) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`i_gonggu`)
);

/* 구매자 */
CREATE TABLE t_gg_buy(
	i_gonggu int(10) unsigned NOT NULL,
	i_user int(10) unsigned NOT NULL,
	i_inv int(10) NOT NULL,
	i_addr varchar(100) NOT NULL,
	created_at datetime DEFAULT CURRENT_TIMESTAMP,
  	FOREIGN KEY (i_gonggu) REFERENCES t_gg_sel (i_gonggu),
  	FOREIGN KEY (i_user) REFERENCES t_user (i_user)	
);
