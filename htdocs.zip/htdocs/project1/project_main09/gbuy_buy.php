<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="ggform.css">
</head>
<body>
    <H2>공동구매 구매자</H2>
    <form action="gbuy_write_proc.php">
        <fieldset>
        제목
        <label><div>식물명</div><input type="text" name="" placeholder="" value="param값"></label><hr>
        
        <textarea class="ctnt" name="" placeholder="설명을 적어주세요">param값</textarea><br>
        <!-- 세션체크후 보임 -->
        <label><select name="" id=""></select><div>계좌번호</div><input type="text" name="acnum" placeholder="세션체크후 보임"></label><hr>
        
        <label><div>구매자명</div><input type="text" name="" placeholder="세션 nm값"></label><hr>
        <label>
            <div>희망수량</div>
            <input type="text" name="" id="a1" placeholder="">
            <input type="text" id="a2" value="3">
        </label><br>
        <input type="button" onclick="aa()">계산</input>
        <input type="text" id="a3">
        <label><div>주소</div><input type="text" name="" placeholder=""></label><br><hr>
        <label><div>연락처</div><input type="text" name="" placeholder=""></label><br><hr>
        <label><div>할말</div><input type="text" name="" placeholder=""></label><br><hr>
        <input class="button" type="submit" value="구매신청">
        </fieldset>
    </form>
    <script>
        function aa(){
            let a1 = document.getElementById("a1").value;
            let a2 = document.getElementById("a2").value;
            let a3 = document.getElementById("a3");
            a3.value=a1*a2;
        }
    </script>
</body>
</html>