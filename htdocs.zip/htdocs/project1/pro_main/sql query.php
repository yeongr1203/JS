create table t_user(
i_user int unsigned primary key auto_increment,
uid varchar(10) unique not null,
upw varchar(8) not null,
nm varchar(8) not null,
adr varchar(20),
email varchar(20),
gender int unsigned not null check(gender in (0,1)),
created_at datetime default CURRENT_TIMESTAMP,
updated_at datetime default CURRENT_TIMESTAMP);

create table t_board(
i_user int unsigned,
i_board int auto_increment primary key,
title varchar(100) not null,
ctnt varchar(2000) not null,
created_at datetime default CURRENT_TIMESTAMP,
updated_at datetime default CURRENT_TIMESTAMP,
view_at int unsigned default 0,
sel_board int not null,
foreign key (i_user) references t_user(i_user));

create table t_gg_sel(
i_gonggu int(10) unsigned not null auto_increment,
title varchar(100) not null,
ctnt varchar(2000) not null,
product_nm varchar(100) not null default '',
bank_num int(10) not null,
price int(10) not null,
created_at datetime default CURRENT_TIMESTAMP,
updated_at datetime default current_timestamp,
start_day varchar(10) not null,
end_day varchar(10) not null,
primary key (i_gonggu) );

create table t_gg_buy(
i_gonggu int(10) unsigned not null,
add_num varchar(10) unsigned not null default '',
i_user int(10) unsigned not null,
i_inv int(10) not null,
i_addr varchar(100) not null,
user_num varchar(30) not null default '',
i_bnm varchar(30) not null default '',
created_at datetime default CURRENT_TIMESTAMP,
i_bnum varchar(10) not null,
foreign key (i_gonggu) REFERENCES t_gg_sel(i_gonggu)
foreign key (i_user) REFERENCES t_user(i_user));
