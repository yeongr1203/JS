<?php
    include_once "db/db_user.php";
    $user_id = $_POST["user_id"];
    $user_pw = $_POST["user_pw"];
    $confirm_pw = $_POST["confirm_pw"];
    $nm = $_POST["nm"];
    $user_num = $_POST['user_num'];

    $param = [
        "user_id" => $user_id,
        "user_pw" => $user_pw,
        "nm" => $nm,
        "user_num" => $user_num
    ];  

    $result = ins_user($param);
    if($result){
        header("location:login_page.php");
    }
    

