<?php

    $arr = [];
    $arr['a'] = 1;
    
    print $arr['a'];    // 3번만 작성하면 에러가 터짐. a라는 값이 없음.
    
    $arr['b'] = 10;     // 없다면  아래 if문 작성시 값이 나타나지 않음.
    if(isset($arr['b'])) {
        print $arr['b'];
    }