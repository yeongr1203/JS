<?php

    $numbers = array (10,20,5=>30,40);      // 이런상태는 for문으로 사용할 수 없다. 
                                            // 이렇게 나올 수 있지만 최대한 사용하지 않기.

    print_r($numbers);
    print "<br>";
    print "count : ".count($numbers);

    for($i=0; $i<count($numbers); $i++)
    {
        print $numbers[$i]."<br>";
    }
    print "--- 끝 ---";

// 인덱스 배열은 보통 숫자.
// 자바에서는 lap이라고 함.




// 보충수업 부분
$number = array (10,20,30,40);

$number[2] = 100;
// $number["2"] = 100; //이렇게 쓰면 정수가 아닌 문자열로 인식이 됨.
// 헷갈리면 정수형과 문자형이 있다라고 생각하기.

print_r($number);
print "<br>";
print "count : ".count($number);








?>