<?php
    $arr_age = array(
        "Peter" => 35,
        "Ben" => 37,
        "Joe" => 43,
        "John" => 24,
    );

    //키 정렬값(키값 유지)
    // asort(오름차순), arsort(내림차순)
    
    $copy_arr_1 = $arr_age; // 주소값만 복사되기때문에 얕은 복사.
    // $copy_arr_1 = &$arr_age; &$arr_age이건 주소값만 복사되는 것. 같은 배열을 가리키고 있는것. 복사가 아니라 원본에 손을 대는 것.
    print "copy:";
    print_r($copy_arr_1);
    print "<br>";
    // $arr_age을 복사해서 $copy_arr_1 여기로 넘겨준다. 프린트하면 분명 같은 값이 나타난다.
    // $copy_arr_1 여기 수정해도 $arr_age여기 값은 수정되지 않는다. 
    // 왜냐면 얕은 복사가 되기 때문에 원본을 손대는 것이 아니다.


?>


<!-- 

SORT는 PHP에서 제공하는 것이다.
SORT & RSORT 는 값을 기준으로 정렬한다.

key값이 없을땐 sort를 사용하는 것이 좋다. 더 빠르기 때문에.
key값이 유지가 되어야 한다면 

 -->