<?php

    $age = 21; 
    print "<div>" . $age . "</div>"; 

    $name;
    print "<div>". $name . "<div>"; 

    $name="홍길동";
    print "<div>". $name . "<div>";   

    $name="장보고";
    print "<div>". $name . "<div>";  

    $name=10;
    print "<div>" . $name . "</div>";

    $a1b=12; 
    print $a1b;

    $_124 = "ㅁㅁㅁㅁ";
    print $_124;
?>

