<?php
    setcookie("country", "Korea");      // 열때마다 데리고 오는 값이 있다.
    // setcookie를 하는 순간. country에 Korea라는 값을 줬음.

    // echo "Country : ", $_COOKIE['country'], "<br>";

    if(isset($_COOKIE['country']))      
    {
        echo "Country : ", $_COOKIE['country'], "<br>";
    }
    // 첫 쿠키 등록 후 아마 false였을 것.   
    // 저장이 클라이언트고, 여기서 응답(Restance)이 왔을때, 다시 요청(Reqest)을 보냈을때 
    // isset이 true가 된다.
    // 새창열어 확인하면 셋쿠키 후 실행이 바로 프린트안됨.
    // 새로고침한다면 country 가 나타남.

    // 쿠키는 F12에서 application - cookie에서 확인 가능.

?>
<a href="cookie2.php">Next page</a>
<!-- 
    쿠키는 내 컴퓨터에 저장이 되어 브라우저에서 불러올 수 있다.
 -->
 <!--  세션과 쿠키는 저장소가 다름.
    세션은 서버에 저장. 
    세션아이디 구분을 위해 쿠키를 사용하긴 함. 

    쿠키는 클라이언트로 저장.
  -->