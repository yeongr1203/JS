<?php
    // session_start(); 없이는 값이 넘어오지 않음.
    // 브라우저 마다 발행이 되기때문에 
    session_start();
    // 세션 디폴트값은 5분? 이고, 
    print $_SESSION['g']. "<br>";
    // 값을 빼는 방법.
    $a=10;

    echo $_SESSION['g'],',', $a;
    // 콤마로 문자 합치기 가능.
    // 에코(echo)는 , 콤마사용.
    // 프린트(print)는 . 점 사용.