<?php

// setcookie 적기전.
// 리퀘스트에 쿠키에 country가 있나 확인.
if(isset($_COOKIE['country'])){
    echo " Country : ", $_COOKIE['country'],"<br>";
}
// 처음에는 아무리 해도 빈칸. 그래서 false가 나타남.
// 처음 요청했을 땐, 비어있었음.
