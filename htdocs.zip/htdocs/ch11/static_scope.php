<?php

// 함수 선언부.
function A(){
    global $n;
    print $n."<br>";
    return; //안적어도 리턴은 있음.
}
// 함수 선언부.
function B(){
    $n = "B";
    // 지역변수 n에다가 B를 담음. 
    // 그래서 global $n과는 상관이 없음.
    A();    // 함수A호출 및 실행됨. 
    return;
}

// 선언부가 아래에 있어도 다 읽고나서 실행됨.
$n = "M";
A();
B();

/*

$n = "M";
A();
B();

// 함수 선언부.
function A(){
    global $n;
    print $n."<br>";
}
// 함수 선언부.
function B(){
    $n = "B";
    A();
}

*/