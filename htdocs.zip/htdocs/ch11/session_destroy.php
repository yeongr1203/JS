<?php
    session_start();    //destroy하려면 앞에 스타트 먼저 적어줘야함.
    // session_unset(); // 언셋은 바로 잊어버리는 것. 

    session_destroy();  // 언셋과는 조금 다름.    
    // 디스트로이를 주로 사용.
    // 디스트로이는 처음창에는 보여주지만 새로고침을 하게 된다면 사라짐.

    // session_regenerate_id(true);    //  세션ID값을 변경한다.
    // 세션은 ID값으로 구분하게 되기때문에.
    
    // unset을 사용한다면 에러가 터지는 이유는 종료가 되어 아래에 값이 없는데
    // 자꾸 값을 달라고 해서 에러터짐. 
    // echo $_SESSION['var1'], "<br>";
    // echo $_SESSION['var2'], "<br>";

    if(isset($_SESSION['var1'])) {
        echo $_SESSION['var1'], "<br>";
    }
    /* 
    echo $_SESSION['var1'], "<br>";
    echo $_SESSION['var2'], "<br>";
    // 자바스크립트와 비교한다면 아래와 같다.
    const obj = null;
    // undefined
    obj.aaa();
    */
?>
<a href="confirm.php">확인</a>
<!-- 

    처음 세션 스타트 했을때, 세션 값들이 나타나 있음. 한번 작동후 다음엔 세션 디스트로이가
    실행이 되어서 세션이 없는 상태가 됨. 그래서 var가 없어짐.
    a태그만 남아 있음.
    == 최초 세션스타트 값은 남음, 그리고 디스트로이는 한 번 보여지고 새로고침하면 사라져버림.

 -->