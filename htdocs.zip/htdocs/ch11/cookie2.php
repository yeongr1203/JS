<?php
    setcookie("country", "한국");   
    // 삭제 주석처리후 실행하면, Korea가 새로고침하면 한국으로 변경됨.
    echo "Country : ", $_COOKIE['country'], "<br>";
    // 쿠키1페이지에 저장된 쿠키 값을 출력함.
    
    $_COOKIE['country'] = "UK";
    echo "Country : ", $_COOKIE['country'], "<br>";
    // 쿠키1 페이지에서 cuntry를 Korea로 저장했지만, 
    // 변경된 값으 보여주긴하지만 내 컴퓨터에 저장 되진 않는다.
    // 쿠키1에서 저장했기 때문에!
    // 혹시 컴퓨터에 저장하고 싶다면 아래처럼 셋쿠키 설정으로 저장해줘야 한다.
    // setcookie("country", "UK");
    // 그럼 값이 Korea 에서 UK로 변경됨.




    // unset($_COOKIE['country']);
    // setcookie("country");
    // 언셋으로 쿠키를 지운다면 안에 저장한 쿠키값까지 다 지워준다.
    // 언셋으로 지우고 안에 저장 값 쿠키까지 다 지워주는게 맞기 때문에 꼭 지워준다.

    echo "Country : ", $_COOKIE['country'], "<br>";
?>