<?php
  if(0) //()안에는 true & false만 올 수 있음. 예- 0빼고 숫자 모두, 변수에 할당되는 순간 true
  {
    print "안녕하세요";
  }  // true면 안녕하세요.
  else
  {
      print "안녕히가세요";
  } // false면 안녕하가세요. else는 옵션이라서 안적어도 됨. 
?>