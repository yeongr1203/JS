<?php
    $result = 1;

    if ($result > 0)
    {
        // to do : result 값을 반으로 만드세요.
        //책 =  $result /2 ;
        //쌤 풀이 아래 2가지.
        // $result = $result * 0.5;
        $result * + 0.5; // 이건 방금 배운것.
        
        print "$result <br>";
        print "position";
    }
    else
    {
        print "$result <br>";
        print "nagative";
    }
?>