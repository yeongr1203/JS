<?php

// 답.
// 1.FALSE
// 2.TRUE
// 3.TRUE
// 4.FALSE
// 5.TRUE
// 6.FALSE
// 7.FALSE
// 8.TRUE
// 9.FALSE

?>