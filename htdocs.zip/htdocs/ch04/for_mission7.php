
<?php

   $star = rand(1,10);
    print "star값은 $star <br>";
   for ($i=1; $i<=$star; $i++)
   {
       print "*";
   }
   print "<br>";
?>
<!-- 

// 조건문 기본은 건들지 말구~

-->



